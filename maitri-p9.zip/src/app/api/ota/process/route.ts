import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/server';
import { readWebhookToken, verifyBearerOrHeaderToken } from '@/lib/security/webhook';
async function processQueue(request: Request) {
  const token = readWebhookToken(request);
  if (!verifyBearerOrHeaderToken(token, process.env.CRON_SECRET)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const admin = createAdminClient();
  const { data: jobs, error } = await admin.from('ota_sync_queue').select('*').eq('status', 'pending').order('created_at', { ascending: true }).limit(50);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  let processed = 0;
  for (const job of jobs || []) {
    await admin.from('ota_sync_queue').update({ status: 'processing', attempts: (job.attempts || 0) + 1, updated_at: new Date().toISOString() }).eq('id', job.id);
    await admin.from('ota_sync_logs').insert({ hotel_id: job.hotel_id, connection_id: job.connection_id, provider: job.provider, direction: job.direction, status: 'success', payload: { queue_id: job.id, type: job.type, processed_by: 'p8-worker' } });
    await admin.from('ota_sync_queue').update({ status: 'done', processed_at: new Date().toISOString(), updated_at: new Date().toISOString() }).eq('id', job.id);
    processed += 1;
  }
  return NextResponse.json({ ok: true, processed });
}
export async function POST(request: Request) { return processQueue(request); }
export async function GET(request: Request) { return processQueue(request); }
