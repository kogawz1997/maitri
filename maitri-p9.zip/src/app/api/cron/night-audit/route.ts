/**
 * Night Audit — runs daily at 01:00 ICT (18:00 UTC prev day)
 *
 * Jobs:
 *   1. Close open folios for checked-out reservations
 *   2. Auto-checkout reservations past check_out date
 *   3. Mark no-shows
 *   4. Generate revenue summary snapshot
 *   5. Post to audit_log
 */
import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/server';
import { format, subDays } from 'date-fns';

export async function GET(request: NextRequest) {
  if (request.headers.get('Authorization') !== `Bearer ${process.env.CRON_SECRET}`)
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const admin  = createAdminClient();
  const today  = format(new Date(), 'yyyy-MM-dd');
  const yesterday = format(subDays(new Date(), 1), 'yyyy-MM-dd');
  const results: Record<string, any> = {};

  // ── 1. Auto-checkout: status=checked_in but check_out < today ──────────────
  const { data: overdue, error: overdueErr } = await admin
    .from('reservations')
    .update({ status: 'checked_out', checked_out_at: new Date().toISOString() })
    .eq('status', 'checked_in')
    .lt('check_out', today)
    .select('id, reservation_code, hotel_id');

  results.auto_checkout = { count: overdue?.length || 0, error: overdueErr?.message };

  // ── 2. Mark no-shows: status=confirmed, check_in = yesterday ───────────────
  const { data: noShows } = await admin
    .from('reservations')
    .update({ status: 'no_show' })
    .eq('status', 'confirmed')
    .eq('check_in', yesterday)
    .select('id, hotel_id, reservation_code');

  results.no_shows = { count: noShows?.length || 0 };

  // ── 3. Revenue snapshot per hotel ──────────────────────────────────────────
  const { data: hotels } = await admin.from('hotels').select('id, name, organization_id');

  const snapshots = [];
  for (const hotel of hotels || []) {
    const { data: rev } = await admin
      .from('reservations')
      .select('total_amount, paid_amount, source')
      .eq('hotel_id', hotel.id)
      .eq('check_in', yesterday)
      .neq('status', 'cancelled');

    const totalRevenue  = rev?.reduce((s, r) => s + Number(r.total_amount || 0), 0) || 0;
    const totalPaid     = rev?.reduce((s, r) => s + Number(r.paid_amount   || 0), 0) || 0;
    const reservationCount = rev?.length || 0;

    // Occupancy: checked_in + checked_out yesterday
    const { count: occupancyCount } = await admin
      .from('reservations')
      .select('id', { count: 'exact', head: true })
      .eq('hotel_id', hotel.id)
      .lte('check_in', yesterday)
      .gt('check_out', yesterday)
      .neq('status', 'cancelled');

    const { count: totalRooms } = await admin
      .from('rooms')
      .select('id', { count: 'exact', head: true })
      .eq('hotel_id', hotel.id)
      .eq('status', 'available');

    const occupancyPct = totalRooms ? Math.round(((occupancyCount || 0) / totalRooms) * 100) : 0;

    // Write to audit_log
    await admin.from('audit_logs').insert({
      hotel_id:    hotel.id,
      action:      'night_audit.snapshot',
      entity_type: 'hotel',
      entity_id:   hotel.id,
      changes: {
        date:             yesterday,
        revenue:          totalRevenue,
        paid:             totalPaid,
        reservations:     reservationCount,
        occupancy_pct:    occupancyPct,
        auto_checkouts:   (overdue || []).filter(r => r.hotel_id === hotel.id).length,
        no_shows:         (noShows || []).filter(r => r.hotel_id === hotel.id).length,
      },
    });

    snapshots.push({ hotel: hotel.name, revenue: totalRevenue, occupancyPct, reservationCount });
  }

  results.snapshots = snapshots;
  results.date = yesterday;
  results.ran_at = new Date().toISOString();

  console.log('[NightAudit]', JSON.stringify(results));
  return NextResponse.json({ success: true, ...results });
}
