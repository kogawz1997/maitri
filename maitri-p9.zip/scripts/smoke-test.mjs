import process from 'node:process';

const baseUrl = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL;
const token = process.env.OPS_READINESS_TOKEN;

if (!baseUrl) {
  console.error('Missing NEXT_PUBLIC_APP_URL or APP_URL');
  process.exit(1);
}

const res = await fetch(`${baseUrl.replace(/\/$/, '')}/api/health`, {
  headers: token ? { Authorization: `Bearer ${token}` } : {},
});
const body = await res.text();
console.log(body);
if (!res.ok) process.exit(1);
